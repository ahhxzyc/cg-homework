#include "TinyEngine.h"
#include "Triangle.h"

// Derive a subclass from the engine
class MyApp : public TinyEngine {
public:
    // Constructor
    MyApp(HINSTANCE hinst, int w, int h, ZBufferType type) : TinyEngine(hinst, w, h, type) {}

    // onInit() gets executed before the loop
    void onInit() override {
        if (!load("../../res/model.obj")) {
            exit(233);
        }
    }

    // onMain() gets executed in the loop
    void onMain() override {
        drawModelLoaded();
        drawOctTree();
    }
};

// Main function for Win32 Application
int WinMain(HINSTANCE hinstance,
			HINSTANCE hprevinstance,
			LPSTR lpcmdline,
			int ncmdshow) {
    MyApp app(hinstance, 600, 600, MyApp::NORMAL);     // Create a window
    app.init();                         // Necessary initializations
    app.mainloop();                     // Enter the main loop where stuff gets shown and mouse/keyboard gets answered
}