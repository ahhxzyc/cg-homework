#include "NaiveZBuffer.h"


NaiveZBuffer::NaiveZBuffer(int w, int h) :
        mWidth(w), mHeight(h) {
    m_pBuffer = new float[w * h];
    clear();
}

NaiveZBuffer::~NaiveZBuffer() {
    delete [] m_pBuffer;
}