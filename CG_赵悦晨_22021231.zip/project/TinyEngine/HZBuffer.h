#pragma once

#include <vector>

class AABB2D;

class HZBuffer {
public:
    HZBuffer(int w, int h);
    ~HZBuffer();

    inline void clear();
    inline float get(int x, int y);
    void set(int x, int y, float z);
    bool reject(AABB2D box, float z);


public:
    int         mWidth;
    int         mHeight;
    int         mSize;

    // 0 - largest layer of the buffer
    // 1 - 1/4 the size of layer 0
    // ... and so on
    std::vector<std::vector<float>> mBuffers;
};

//
// Clear the entire buffer to -inf
//
void HZBuffer::clear()              {for (auto &v:mBuffers) v.assign(v.size(), -1e10);}

//
// Get the buffered z value at (x,y)
//
float HZBuffer::get(int x, int y)   {return mBuffers[0][x + y * mSize];}
