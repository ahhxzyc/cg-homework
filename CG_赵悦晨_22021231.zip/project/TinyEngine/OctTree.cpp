#include "OctTree.h"
#include "TinyEngine.h"
#include "HZBuffer.h"
#include <stack>

int OctTree::build(AABB3D box, const std::vector<int> &indices) {
    if (indices.empty())
        return -1;
    int nodei = newNode();
    mNodes[nodei].mBox = box;
    std::vector<bool>   taken(indices.size(), false);
    for (int i = 0; i < 8; i ++ ) {
        std::vector<int> subIndices;
        AABB3D subbox = box.getSubBox(i);
        for (int j = 0; j < indices.size(); j ++ ) {
            if (taken[j])
                continue;
            if (subbox.contain(mObjects[indices[j]])) {
                subIndices.push_back(indices[j]);
                taken[j] = true;
            }
        }
        mNodes[nodei].mChildren.push_back(build(subbox, subIndices));
    }
    for (int i = 0; i < indices.size(); i ++ ) {
        if (!taken[i]) 
            mNodes[nodei].mIndices.push_back(indices[i]);
    }
    return nodei;
}

//
// Draw the octtree as wireframe cubes
//
void OctTree::drawOctTree() {
    std::stack<int> stk;
    stk.push(mRoot);
    while (stk.size()) {
        int r = stk.top();
        stk.pop();
        if (r == -1)
            continue;
        AABB3D box = mNodes[r].mBox;
        m_pEngine->drawCube(box.minp, box.maxp, Vector3f(1,0.5,0.5), false);
        for (int idx : mNodes[r].mChildren)
            stk.push(idx);
    }
}

//
// Traverse the octtree to draw the objects
//
void OctTree::draw(HZBuffer *p_hzbuffer) {
    int w = p_hzbuffer->mWidth;
    int h = p_hzbuffer->mHeight;
    std::stack<int> stk;
    stk.push(mRoot);
    while (stk.size()) {
        int r = stk.top();
        stk.pop();
        if (r == -1)
            continue;

        // See if the box can be rejected
        const AABB3D &box3d = mNodes[r].mBox;
        AABB2Df boxf(Vector2f(box3d.minp[0], box3d.minp[1]), Vector2f(box3d.maxp[0], box3d.maxp[1]));
        AABB2D box( Vector2i((boxf.maxp[0] + 1.f) * 0.5f * w, (boxf.maxp[1] + 1.f) * 0.5 * h),
                Vector2i((boxf.minp[0] + 1.f) * 0.5f * w, (boxf.minp[1] + 1.f) * 0.5 * h));
        float maxz = box3d.maxp[2];
        if (p_hzbuffer->reject(box, maxz))
            continue;
        
        // Traverse the subtree & draw the objects in this node
        for (int idx : mNodes[r].mChildren)
            stk.push(idx);
        for (int idx : mNodes[r].mIndices) {
            const Triangle3D &tri = mObjects[idx];
            m_pEngine->drawTriangle(tri);
        }
    }
}