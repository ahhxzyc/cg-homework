#pragma once

#include "windows.h"
#include "Trackball.h"
#include "Transform.h"
#include "Triangle.h"
#include "OctTree.h"
#include <ctime>
#include <string>
#include <queue>
#include <algorithm>
#include <Eigen/Dense>

using Eigen::Vector3f;
using Eigen::Vector3i;
using Eigen::Matrix4f;
using Eigen::Vector4f;
using Eigen::Vector2f;
using Eigen::Vector2i;

class Triangle2D;
class NaiveZBuffer;
class HZBuffer;

class TinyEngine {
public:
    // The type of z-buffer that should be used for rendering
    enum ZBufferType {
        NORMAL,
        HIERARCHICAL,
        HIERARCHICAL_WITH_OCTTREE
    };

public:
    
    TinyEngine(HINSTANCE hinst, int w, int h, ZBufferType ztype);
    ~TinyEngine();
    
    void init();
    void mainloop();

    inline void setPixel(int x, int y, const Vector3f &color);
    inline void drawPoint(int x, int y, int sz, const Vector3f &color);
    void drawLine(Vector2i p0, Vector2i p1, const Vector3f &color);
    void drawLine(const Vector3f &p0, const Vector3f &p1, const Vector3f &color, bool rotation);
    void drawPoint(const Vector3f &p, int sz, const Vector3f &color);
    void drawTriangle(const Triangle3D &tri, const Vector3f &color);
    void drawTriangle(const Triangle3D &tri);
    void drawCube(const Vector3f &p0, const Vector3f &p1, const Vector3f &color, bool rotation);
    inline void drawOctTree();
    void drawModelLoaded();
    inline void clear();
    inline void constructOctTree();
    inline void destroyOctTree();

    inline void onPaint();
    void onMousePressed();
    void onMouseReleased();
    
    virtual void onInit()               {}
    virtual void onMain()               {}
    virtual void onDestroy()            {}
    virtual void onUserMousePressed()   {}
    virtual void onUserMouseReleased()  {}

protected:
    bool load(const std::string &filename);


public:
    static LRESULT CALLBACK win_procedure(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
private:
    inline void clamp_cursor_pos();
    void render();
    float findFps();
    inline void applyTransformations();
    void updateWindowTitle();
    void updateMousePos();
    void updateTrackball();
    inline Vector4f to_vec4f(Vector3f v, float f);
    inline Vector3f to_vec3f(Vector4f v);
    inline Vector2f to_vec2f(Vector3f v);
    inline Vector2f to_vec2f(Vector4f v);
    inline void to_screen(const Vector3f &v, Vector2i &p, bool rotation);
    inline void barycentric(const Vector2f &p, const Triangle2D &tri, Vector3f &baryCoords);

private:
    int             mWidth;
    int             mHeight;
    // zbuffer
    ZBufferType     mZBufferType;
    NaiveZBuffer    *m_pZBuffer = nullptr;
    HZBuffer        *m_pHZBuffer = nullptr;
    // windows stuff
    HINSTANCE       m_hInst;
    HWND            m_hWnd;
    HDC             m_hDC;
    // for frame buffer
    HBITMAP         m_hBufferBitmap;
    HDC             m_hBufferDC;
    BYTE            *mFrameBuffer;    // automatically released
    // for fps counting
    clock_t             mLastTime = 0;
    clock_t             mCurTime = 0;
    std::queue<float>   m_qTimes;
    float               mTimeSum = 0.f;
    // for cursor pos
    POINT               mMousePos;
    RECT                mClientRect;
    bool                m_bCursorInWindow;
    // matrix
    Matrix4f            mModel;
    // trackball
    Trackball           mTrackball;
    Transform           mTransform;
    bool                m_bMousePressed = false;
    // Model data
    std::vector<Triangle3D> mTransformedTriangles;
    std::vector<Triangle3D> mTriangles;
    // OctTree
    OctTree     *m_pOctTree;
};

//
// Set the color of a pixel
//
void TinyEngine::setPixel(int x, int y, const Vector3f &color) {
    if (x < 0 || x >= mWidth || y < 0 || y >= mHeight)
        return ;
    BYTE *base = mFrameBuffer + (x + y * mWidth) * 3;
    // Windows somehow have the order of RGB's reversed in the frame buffer
    base[0] = static_cast<BYTE>(color[2] * 255);
    base[1] = static_cast<BYTE>(color[1] * 255);
    base[2] = static_cast<BYTE>(color[0] * 255);
}

//
// Draw point of a certain size
//
void TinyEngine::drawPoint(int x, int y, int sz, const Vector3f &color) {
    if (sz < 1)
        return;
    int offset = (sz - 1) / 2;
    x -= offset;
    y -= offset;
    for (int i = 0; i < sz; i ++ )
        for (int j = 0; j < sz; j ++ )
            setPixel(x + i, y + j, color);
}

//
// Clear screen to complete white
//
void TinyEngine::clear() {
    memset(mFrameBuffer, 255, mWidth * mHeight * 3);
}

Vector4f TinyEngine::to_vec4f(Vector3f v, float f)    {return Vector4f(v[0], v[1], v[2], f);}
Vector3f TinyEngine::to_vec3f(Vector4f v)             {return Vector3f(v[0], v[1], v[2]);}
Vector2f TinyEngine::to_vec2f(Vector3f v)             {return Vector2f(v[0], v[1]);}
Vector2f TinyEngine::to_vec2f(Vector4f v)             {return Vector2f(v[0], v[1]);}

//
// Convert a 3D point to 2D point on screen
//
void TinyEngine::to_screen(const Vector3f &v, Vector2i &p, bool rotation) {
    Vector4f v4 = rotation ? mModel * to_vec4f(v, 1.f) : to_vec4f(v, 1.f);
    p[0] = (v4[0] + 1.f) * 0.5f * mWidth;
	p[1] = (v4[1] + 1.f) * 0.5f * mHeight;
}


void TinyEngine::constructOctTree() {
    AABB3D box(Vector3f(-2,-2,-2), Vector3f(2,2,2));
    m_pOctTree = new OctTree(box, mTransformedTriangles, this);
}

void TinyEngine::destroyOctTree() {
    delete m_pOctTree;
    m_pOctTree = nullptr;
}

//
// Return barycentric coordinates of point P for the triangle
//
void TinyEngine::barycentric(const Vector2f& p, const Triangle2D& tri, Vector3f& baryCoords) {
    Vector2f ab = tri.b() - tri.a();
    Vector2f ac = tri.c() - tri.a();
    Vector2f pa = tri.a() - p;
    Vector3f x(ab[0], ac[0], pa[0]);
    Vector3f y(ab[1], ac[1], pa[1]);
    Vector3f u = x.cross(y);
    // See if the triangle is degenerate(three vertices on a line)
    if (u[2] < 1e-10) {
        baryCoords[0] = -1;
        baryCoords[1] = baryCoords[2] = 1;
        return;
    }
    // Return barycentric coords
    float div = 1.f / u[2];
    float uu = u[0] * div;
    float vv = u[1] * div;
    baryCoords[0] = 1.f - uu - vv;
    baryCoords[1] = uu;
    baryCoords[2] = vv;
}

//
// Apply matrix transformations(MVP) to the loaded model
//
void TinyEngine::applyTransformations() {
    if (m_bMousePressed)    mModel = mTransform.rotate(mTrackball.getRotation()).getMatrix();
    else                    mModel = mTransform.getMatrix();
	// Matrix Transformation
	mTransformedTriangles.clear();
	for (const Triangle3D &tri : mTriangles) {
		Triangle3D transTri;
		for (int i = 0; i < 3; i ++ )
			transTri.v[i] = to_vec3f(mModel * to_vec4f(tri.v[i], 1.f));
		mTransformedTriangles.push_back(transTri);
	}
}

//
// Things that should be done on receiving a WM_PAINT message
//
void TinyEngine::onPaint() {
    updateMousePos();
    updateTrackball();
    applyTransformations();

    if (mZBufferType == HIERARCHICAL_WITH_OCTTREE)
        constructOctTree();
    render();
    if (mZBufferType == HIERARCHICAL_WITH_OCTTREE)
        destroyOctTree();

    updateWindowTitle();
}


void TinyEngine::drawOctTree() {
    if (m_pOctTree)
        m_pOctTree->drawOctTree();
}