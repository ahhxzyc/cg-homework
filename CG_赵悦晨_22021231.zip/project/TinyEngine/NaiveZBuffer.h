#pragma once

#include <algorithm>

class NaiveZBuffer {


public:
    NaiveZBuffer(int w, int h);
    ~NaiveZBuffer();

    inline void clear();
    inline float get(int x, int y);
    inline void set(int x, int y, float z);

private:
    float       *m_pBuffer;
    int         mWidth;
    int         mHeight;
};


void NaiveZBuffer::clear()                       {std::fill(m_pBuffer, m_pBuffer + mWidth * mHeight, -1e10);}
float NaiveZBuffer::get(int x, int y)            {return m_pBuffer[y * mWidth + x];}
void NaiveZBuffer::set(int x, int y, float z)    {m_pBuffer[y * mWidth + x] = z;}