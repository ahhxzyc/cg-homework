
#include "HZBuffer.h"
#include "AABB.h"
#include <algorithm>
#include <stdexcept>

using Eigen::Vector2i;


HZBuffer::HZBuffer(int w, int h) :
        mWidth(w), mHeight(h) {
    // Pick a size
    int size_list[] = {32, 64, 128, 256, 512, 1024, 2048, 4096};
    mSize = (std::max)(w, h);
    for (int len : size_list) {
        if (len < mSize)      continue;
        while (len > mSize)   mSize ++ ;
        if (len == mSize)     break;
    }
    // Then init
    for (int sz = mSize; sz; sz >>= 1) {
        mBuffers.emplace_back(sz * sz);
    }
}


HZBuffer::~HZBuffer() {
    // empty
}


//
// Return true if the bounding box is to be rejected
// z - max z value of the object
//
bool HZBuffer::reject(AABB2D box, float z) {
    Vector2i base(0, 0);
    int sz = mSize;
    while (sz >= 2) {
        // 4 subboxes
        bool found = false;
        int tempsize = sz >> 1;
        for (int i = 0; i < 4; i ++ ) {
            int fx = i % 2;
            int fy = i / 2;
            Vector2i temp_base  (base[0] + fx * tempsize, base[1] + fy * tempsize);
            Vector2i top_right  (temp_base[0] + tempsize - 1, temp_base[1] + tempsize - 1);
            AABB2D temp_box     (temp_base, top_right);
            if (temp_box.contain(box)) {
                // Access buffer for z value
                int x = temp_base[0] / tempsize;
                int y = temp_base[1] / tempsize;
                int bufsize = mSize / tempsize;
                // Find the buffer's index in mBuffers
                int idx = 0, temp = mSize;
                while (temp > bufsize){
                    temp >>= 1;
                    idx ++ ;
                }
                // Check
                float value = 0;
                value = mBuffers[idx][x + y * bufsize];
                if (z < value) {
                    return true;  // box is rejected
                } else {
                    // subbox -> the box
                    found = true;
                    base = temp_base;
                    sz = tempsize;
                    break;
                }
            }
        }
        if (!found) break;
    }
    // render the triangle
    return false;
}

//
// Update a z value in the hierarchical z-buffer
//
void HZBuffer::set(int x, int y, float z) {
    for (int i = 0, sz = mSize; i < mBuffers.size(); i ++ , sz >>= 1, x >>= 1, y >>= 1) {
        float &val = mBuffers[i][x + y * sz];
        if (i == 0)     val = z;
        else            val = (std::min)(val, z);
    }
}